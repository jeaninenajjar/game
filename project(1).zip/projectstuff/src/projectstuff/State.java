package projectstuff;

public enum State {
	NEUTRAL, INVINCIBLE, SPEEDUP
}
