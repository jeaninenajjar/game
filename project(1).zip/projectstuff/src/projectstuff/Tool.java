package projectstuff;

public enum Tool {
	TRASH, RECYCLE, COMPOST
}
