package projectstuff;

import static org.junit.Assert.*;

import org.junit.Test;

public class PlayerTest {

	@Test
	public void test() {
		Player aplayer = new Player(0, 0, 0, 0, 2, 0, 0, Tool.TRASH, State.NEUTRAL);
		aplayer.setLife(0);
	     aplayer.LoseLife();
		assertTrue(aplayer.getLife()==0);
		aplayer.setLife(3);
		aplayer.LoseLife();
		assertTrue(aplayer.getLife()==2);
		
		aplayer.Invincibility();
		assertTrue(aplayer.getState() == State.INVINCIBLE);
		
		aplayer.SpeedUp();
		assertTrue(aplayer.getState() == State.SPEEDUP);
		
		aplayer.FlipSalinity();
		assertTrue(aplayer.getSalinity() == -2 );
		
		
		aplayer.SwitchTool();
		assertTrue(aplayer.getTool() == Tool.RECYCLE);
		aplayer.SwitchTool();
		assertTrue(aplayer.getTool() == Tool.COMPOST);
		aplayer.SwitchTool();
		assertTrue(aplayer.getTool() == Tool.TRASH);
		
		
		

		
	}
}
