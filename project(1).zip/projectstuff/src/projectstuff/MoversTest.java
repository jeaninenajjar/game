package projectstuff;

import static org.junit.Assert.*;

import org.junit.Test;

public class MoversTest {

	@Test
	public void test() {
		Movers mover = new Movers(5, 5, 5, 5);
		mover.moveX(6);
		assertTrue(mover.getXpos() == 11);
		mover.moveY(7);
		assertTrue(mover.getYpos() == 12);
	}

}
